package com.kayserboost.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.kayserboost.KayserBoostClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class BoostConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("kayserboost.json");

    public boolean showHud = true;
    public boolean showFps = true;
    public boolean showFrameTime = true;
    public boolean showMemory = true;
    public boolean showChunkInfo = true;
    public int hudX = 6;
    public int hudY = 6;
    public boolean compactHud = true;

    public static BoostConfig load() {
        BoostConfig config = new BoostConfig();
        try {
            if (Files.exists(FILE)) {
                BoostConfig loaded = GSON.fromJson(Files.readString(FILE, StandardCharsets.UTF_8), BoostConfig.class);
                if (loaded != null) config = loaded;
            }
            config.save();
        } catch (Exception e) {
            KayserBoostClient.LOGGER.error("Não foi possível carregar kayserboost.json; usando padrões.", e);
            config = new BoostConfig();
            config.save();
        }
        return config;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this), StandardCharsets.UTF_8);
        } catch (IOException e) {
            KayserBoostClient.LOGGER.error("Não foi possível salvar a configuração.", e);
        }
    }
}
