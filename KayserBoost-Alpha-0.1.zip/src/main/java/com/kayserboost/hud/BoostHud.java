package com.kayserboost.hud;

import com.kayserboost.config.BoostConfig;
import com.kayserboost.monitor.PerformanceMonitor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public final class BoostHud {
    private BoostHud() {}

    public static void render(MatrixStack matrices, PerformanceMonitor monitor, BoostConfig config) {
        MinecraftClient client = MinecraftClient.getInstance();
        int x = Math.max(0, config.hudX);
        int y = Math.max(0, config.hudY);
        int line = 0;

        client.textRenderer.drawWithShadow(matrices, "§bKayserBoost §7Alpha 0.1", x, y + line++ * 10, 0xFFFFFF);

        if (config.showFps) {
            client.textRenderer.drawWithShadow(matrices, "§aFPS: §f" + monitor.getFps(), x, y + line++ * 10, 0xFFFFFF);
        }
        if (config.showFrameTime) {
            String frameTime = String.format(java.util.Locale.ROOT, "%.1f ms", monitor.getFrameTimeMs());
            client.textRenderer.drawWithShadow(matrices, "§eFrame: §f" + frameTime, x, y + line++ * 10, 0xFFFFFF);
        }
        if (config.showMemory) {
            client.textRenderer.drawWithShadow(matrices,
                    "§dHeap: §f" + monitor.getUsedMemoryMb() + " / " + monitor.getMaxMemoryMb() + " MB",
                    x, y + line++ * 10, 0xFFFFFF);
        }
        if (config.showChunkInfo) {
            client.textRenderer.drawWithShadow(matrices,
                    "§7Chunks: §f" + monitor.getLoadedChunkCount() + " §7| Entidades: §f" + monitor.getLoadedEntityCount(),
                    x, y + line * 10, 0xFFFFFF);
        }
    }
}
