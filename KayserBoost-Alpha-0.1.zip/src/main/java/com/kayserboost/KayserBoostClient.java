package com.kayserboost;

import com.kayserboost.config.BoostConfig;
import com.kayserboost.hud.BoostHud;
import com.kayserboost.monitor.PerformanceMonitor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class KayserBoostClient implements ClientModInitializer {
    public static final String MOD_ID = "kayserboost";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static BoostConfig config;
    private static final PerformanceMonitor MONITOR = new PerformanceMonitor();

    @Override
    public void onInitializeClient() {
        config = BoostConfig.load();
        HudRenderCallback.EVENT.register((matrices, tickDelta) -> {
            MONITOR.recordFrame();
            if (config.showHud && net.minecraft.client.MinecraftClient.getInstance().player != null) {
                BoostHud.render(matrices, MONITOR, config);
            }
        });
        LOGGER.info("KayserBoost Alpha 0.1 inicializado.");
    }

    public static BoostConfig config() {
        return config;
    }

    public static PerformanceMonitor monitor() {
        return MONITOR;
    }
}
