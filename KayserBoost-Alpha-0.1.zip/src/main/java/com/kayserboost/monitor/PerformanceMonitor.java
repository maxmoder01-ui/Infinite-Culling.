package com.kayserboost.monitor;

/**
 * Lightweight client-side frame sampler. It measures; it does not change game settings.
 */
public final class PerformanceMonitor {
    private long sampleStartNanos = System.nanoTime();
    private int frames;
    private int fps;
    private long previousFrameNanos;
    private double frameTimeMs;

    public void recordFrame() {
        long now = System.nanoTime();
        frames++;

        if (previousFrameNanos != 0L) {
            double currentFrameMs = (now - previousFrameNanos) / 1_000_000.0;
            if (currentFrameMs > 0.0 && currentFrameMs < 10_000.0) {
                frameTimeMs = frameTimeMs == 0.0
                        ? currentFrameMs
                        : (frameTimeMs * 0.8) + (currentFrameMs * 0.2);
            }
        }
        previousFrameNanos = now;

        long elapsed = now - sampleStartNanos;
        if (elapsed >= 1_000_000_000L) {
            fps = (int) Math.round(frames * (1_000_000_000.0 / elapsed));
            frames = 0;
            sampleStartNanos = now;
        }
    }

    public int getFps() {
        return fps;
    }

    public double getFrameTimeMs() {
        return frameTimeMs;
    }

    public long getUsedMemoryMb() {
        Runtime runtime = Runtime.getRuntime();
        return (runtime.totalMemory() - runtime.freeMemory()) / (1024L * 1024L);
    }

    public long getMaxMemoryMb() {
        return Runtime.getRuntime().maxMemory() / (1024L * 1024L);
    }

    public int getLoadedEntityCount() {
        net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
        return client.world == null ? 0 : client.world.getRegularEntityCount();
    }

    public int getLoadedChunkCount() {
        net.minecraft.client.MinecraftClient client = net.minecraft.client.MinecraftClient.getInstance();
        return client.world == null ? 0 : client.world.getChunkManager().getLoadedChunkCount();
    }
}
