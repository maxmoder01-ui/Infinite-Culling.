# KayserBoost Alpha 0.1

Mod client-side para Minecraft Java **1.18.2 + Fabric**, planejado para testes em Android usando Zalith Launcher.

## Estado desta entrega

Esta é a fundação inicial do projeto, não uma versão final de otimização. Ela inclui:

- Inicializador Fabric para cliente.
- Configuração persistente em `config/kayserboost.json`.
- HUD com FPS medido no callback de HUD e frametime suavizado, memória Java, chunks e entidades.
- Monitoramento leve, sem alterar automaticamente as configurações do jogo.

**Importante:** a medição de FPS/frametime desta primeira versão é preliminar. O contador usa amostragem no ciclo do cliente e não substitui um profiler de frames dedicado. O número de memória é o heap Java, não toda a RAM consumida pelo Android. A amostragem de frames depende do callback de HUD e deve ser comparada com um profiler externo.

## Requisitos

- Minecraft Java 1.18.2
- Fabric Loader 0.14.0 ou superior
- Fabric API para 1.18.2
- Java 17 para compilar e executar

## Compilar

Em um ambiente com JDK 17 e Gradle 8.x:

```bash
gradle build
```

O JAR será criado em:

```text
build/libs/kayserboost-0.1.0-alpha.jar
```

Copie o JAR para a pasta `mods` da instância Fabric 1.18.2 no Zalith.

## Configuração

Após iniciar o jogo uma vez, edite:

```text
.minecraft/config/kayserboost.json
```

Opções disponíveis:

- `showHud`: liga/desliga o HUD.
- `showFps`: exibe FPS.
- `showFrameTime`: exibe estimativa de frametime.
- `showMemory`: exibe heap Java utilizado/máximo.
- `showChunkInfo`: exibe chunks e entidades.
- `hudX`, `hudY`: posição do HUD.
- `compactHud`: reservado para layout compacto futuro.

## Próximas etapas técnicas

1. Substituir a estimativa de FPS por medição de frames real.
2. Implementar culling de entidades com testes de compatibilidade.
3. Implementar redução configurável de partículas.
4. Avaliar otimizações de chunks e memória sem duplicar funções de mods existentes.
5. Criar tela de configurações dentro do jogo.
6. Testar em Zalith com logs e medições antes/depois.

## Filosofia

KayserBoost não deve prometer FPS sem medição. Cada módulo deve ser opcional, isolado e testado em Minecraft 1.18.2.
